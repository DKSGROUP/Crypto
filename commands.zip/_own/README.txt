A Pen created at CodePen.io. You can find this one at https://codepen.io/msurguy/pen/sbIio.

 This is my open source project that allows creating some incredible wallpapers/web site graphics, feel free to improve on it and use it for commercial or free projects